import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isAdmin: boolean = false; // Default value
  username: string = '';

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Example logic to determine if the user is an admin
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.isAdmin = user?.role_id == '1';
    this.username = user?.username || ''; // Get username from local storage

  }

  shouldDisplayLayout(): boolean {
    // Hide sidebar and header for login and home routes
    return !(this.router.url === '/login') && !(this.router.url === '/');
  }
  isSidenavOpen = true; // Set to false for mobile view

  toggleSidenav(): void {
    this.isSidenavOpen = !this.isSidenavOpen;
  }
  async logout(): Promise<void> {
    try {
      // Clear user session
      await Promise.all([
        localStorage.removeItem('user'),
        localStorage.removeItem('token')
      ]);
  
      // Verify storage is cleared
      const userCheck = localStorage.getItem('user');
      const tokenCheck = localStorage.getItem('token');
  
      if (userCheck || tokenCheck) {
        throw new Error('Failed to clear storage');
      }
  
      // Redirect to login page
      await this.router.navigate(['/login']);
  
    } catch (error) {
      console.error('Logout error:', error);
      // Force clear storage and redirect on error
      localStorage.clear();
      await this.router.navigate(['/login']);
    }
    
  }
}