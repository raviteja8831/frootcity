export interface Product {
  id: number;
  title: string;
  description: string;
  category: string;
  status:number;
  selected?: boolean; // Optional property to track selection
  quantity?: number;  // Optional property for quantity
}