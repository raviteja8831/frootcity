import { NgModule } from '@angular/core';
import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { ProductsListComponent } from './components/products-list/products-list.component';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { OrderComponent } from './components/order/order.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';
import { ProductStatusComponent } from './components/product-status/product-status.component';
import { HomeComponent } from './components/home/home.component';
import { SupplyDateComponent } from './components/supply-date/supply-date.component';

const routes: Routes = [
  { path:'update-product', component: ProductStatusComponent, canActivate: [AuthGuard] },
  { path:'update-sd', component: SupplyDateComponent, canActivate: [AuthGuard] }, // Add this route
  // Add this route
  { path: '', component: HomeComponent }, // Redirect to login if no path is provided
  { path: 'products', component: ProductsListComponent, canActivate: [AuthGuard]  },
  { path: 'register', component: UserRegistrationComponent, canActivate: [AuthGuard] },
  { path: 'login', component: UserLoginComponent, canActivate: [AuthGuard] },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'orders', component: OrderComponent, canActivate: [AuthGuard] }, // Add this route


];
const routerOptions: ExtraOptions = {
  anchorScrolling: 'enabled', // Enable anchor scrolling
  scrollPositionRestoration: 'enabled', // Restore scroll position on navigation
};
@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled', // Restores scroll position on navigation
      anchorScrolling: 'enabled' // Enables fragment scrolling
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
