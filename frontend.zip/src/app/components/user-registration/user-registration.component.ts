import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css'],
})
export class UserRegistrationComponent {
  user = {
    username: '',
    email: '',
    password: '',
    roles: ['StoreAdmin'], // Default role
  };
  hidePassword = true;

  message = '';

  constructor(private userService: UserService,
        private snackBar: MatSnackBar
    
  ) {}

  registerUser(): void {
    this.userService.register(this.user).subscribe({
      next: (res) => {
        this.message = 'User registered successfully!';
        this.snackBar.open(this.message, 'Close', {
          duration: 3000, // Duration in milliseconds
          verticalPosition: 'top', // Position on the screen
          });      },
      error: (e) => {
        console.error(e);
        this.message = 'An error occurred during registration.';
        this.snackBar.open(this.message, 'Close', {
          duration: 3000, // Duration in milliseconds
          verticalPosition: 'top', // Position on the screen
          });  
      },
    });
  }
}