import { ViewportScroller } from '@angular/common';
import { AfterViewInit, Component } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements AfterViewInit{

  constructor(private router:Router,
    private viewportScroller: ViewportScroller,
private iconRegistry: MatIconRegistry,
 private sanitizer: DomSanitizer  ) {
   iconRegistry.addSvgIcon(
      'whatsapp',
      sanitizer.bypassSecurityTrustResourceUrl('assets/icons/whatsapp.svg')
   );
   iconRegistry.addSvgIcon(
      'instagram',
      sanitizer.bypassSecurityTrustResourceUrl('assets/icons/instagram.svg')
   );
   iconRegistry.addSvgIcon(
      'facebook',
      sanitizer.bypassSecurityTrustResourceUrl('assets/icons/facebook.svg')
   );
   iconRegistry.addSvgIcon(
      'linkedin',
      sanitizer.bypassSecurityTrustResourceUrl('assets/icons/linkedin.svg')
   );
 }
  // List of clients for the Clients Section
  clients: string[] = [
    'Vijetha Super Markets',
    'Reliance Fresh',
    'Ushodaya Super Market',
    'Sampoorna Super Market',
    'More Super Market',
    'Lulu Mall',
    'SAP Labs India Pvt Ltd',
    'Ariba Technologies India Pvt Ltd',
    'Concur Technologies India Pvt Ltd',
    'Callidus Cloud India Pvt Ltd',
    'State Street',
    'GAP',
    'DBS'
  ];

  // List of advantages for the About Us Section
  advantages: string[] = [
    'Reliable supply base with uninterrupted and lean supply-based mechanism',
    'Handling volumes of a wide range of diversified fruits and fresh product portfolios',
    'Driven by QUALITY Consciousness at all levels and at all times',
    'Affordable rates as the company directly deals with imports and growers domestically',
    'Professionally Managed Company with defined operational TATs',
    'Committed to enhancing the grower-consumer interface'
  ];
  videos: string[] = [
    'https://www.youtube.com/embed/dUoCbZm452E?si=yhLJZd7X8E-NzMtJ',
    'https://www.youtube.com/embed/6OfZvOE0_xQ'
  ];

  // List the image URLs from assets/media folder
  images: string[] = [
    'assets/media/1.jpeg',
    'assets/media/2.jpeg',
    'assets/media/3.jpeg',
    'assets/media/4.jpeg'
  ];
 
  // Navigate to the login page (placeholder for actual navigation logic)
  navigateToLogin(): void {
    console.log('Navigating to login...');
    // Add navigation logic here if needed
    this.router.navigate(['/login']);

  }
  menuOpen: boolean = false;

  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }
  activeTab: string = 'profile'; // Default active tab


  setActiveTab(tab: string) {
    this.activeTab = tab;
  }
  scrollTo(section: string): void {
    const headerHeight = document.querySelector('.fixed-header')?.clientHeight || 0; // Dynamically get header height
    const buffer = 150; // Add a small buffer to adjust the scroll position
    const yOffset = -(headerHeight + buffer); // Offset to account for the fixed header and buffer
    const element = document.getElementById(section);
  
    if (element) {
      const targetPosition = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      this.smoothScrollTo(window.pageYOffset, targetPosition, 600); // 600ms duration
    }
  }
  
  smoothScrollTo(start: number, end: number, duration: number): void {
    const distance = end - start;
    const startTime = performance.now();
  
    const easeInOutQuad = (t: number): number => {
      return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    };
  
    const scroll = (currentTime: number): void => {
      const elapsedTime = currentTime - startTime;
      const progress = Math.min(elapsedTime / duration, 1); // Ensure progress doesn't exceed 1
      const ease = easeInOutQuad(progress);
      window.scrollTo(0, start + distance * ease);
  
      if (elapsedTime < duration) {
        requestAnimationFrame(scroll);
      }
      if (elapsedTime < duration) {
        requestAnimationFrame(scroll);
      } else {
        this.menuOpen = false; // Close the menu after scrolling
      }
    };
  
    requestAnimationFrame(scroll);
  }
  currentSlide = 0;

  prevSlide() {
      this.currentSlide = (this.currentSlide === 0) ? 4 : this.currentSlide - 1;
  }
  
  nextSlide() {
      this.currentSlide = (this.currentSlide === 4) ? 0 : this.currentSlide + 1;
  }
  
  goToSlide(index: number) {
      this.currentSlide = index;
  }
  ngAfterViewInit(): void {
    setInterval(() => {
      this.nextSlide(); // Reuse your existing nextSlide() method
   
    }, 3000); // Change slide every 3 seconds
  }
  sanitizeVideoUrl(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}