import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-supply-date',
  templateUrl: './supply-date.component.html',
  styleUrls: ['./supply-date.component.css']
})
export class SupplyDateComponent implements OnInit {
  supplyDate: Date | null = null; // Store as a Date object

  constructor(private userService: UserService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.loadSupplyDate();
  }

  // Load the supply date using the UserService
  loadSupplyDate(): void {
    this.userService.getSupplyDate().subscribe(
      (data) => {
        console.log('Supply date loaded:', data.supplydate);

        // Parse the date in dd-MM-yyyy format
        const [day, month, year] = data[0].supplydate.split('-').map(Number);
        this.supplyDate = new Date(year, month - 1, day); // Month is 0-based in JavaScript
        console.log('Parsed supply date:', this.supplyDate);
      },
      (error) => {
        console.error('Error loading supply date:', error);
      }
    );
  }

  // Save the updated supply date using the UserService
  saveSupplyDate(): void {
    if (this.supplyDate) {
      // Format the date to dd-MM-yyyy before saving
      const formattedDate = this.supplyDate.toLocaleDateString('en-GB').split('/').join('-'); // dd-MM-yyyy format
      const updatedSupplyDate = { date: formattedDate, id:1 };

      this.userService.updateSupplyDate(updatedSupplyDate).subscribe(
        () => {
          const msg = 'Supply date updated successfully.';
          this.snackBar.open(msg, 'Close', {
            duration: 2000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
        },
        (error) => {
          const msg = 'Error updating supply date.';
          this.snackBar.open(msg, 'Close', {
            duration: 2000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
          console.error('Error updating supply date:', error);
        }
      );
    }
  }
}