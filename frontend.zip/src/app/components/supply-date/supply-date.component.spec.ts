import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupplyDateComponent } from './supply-date.component';

describe('SupplyDateComponent', () => {
  let component: SupplyDateComponent;
  let fixture: ComponentFixture<SupplyDateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SupplyDateComponent]
    });
    fixture = TestBed.createComponent(SupplyDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
