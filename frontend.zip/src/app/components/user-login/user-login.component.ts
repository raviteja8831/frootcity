import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Route, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css'],
})
export class UserLoginComponent {
  user = {
    email: '',
    password: '',
  };
  message = '';
  accessToken = '';
  hidePassword = true;

  constructor(private userService: UserService,
    private router: Router,
        private snackBar: MatSnackBar
    
  ) {}

  async loginUser(): Promise<void> {
    try {
      const res = await this.userService.login(this.user).toPromise();
      if (!res) throw new Error('No response from server');
  
      // Clear storage first and wait
      localStorage.clear();
      sessionStorage.clear();
      await new Promise(resolve => setTimeout(resolve, 500));
  
      // Store user data with a unique timestamp to force refresh
      const userData = {
        ...res,
        loginTimestamp: new Date().getTime()
      };
      
      const userString = JSON.stringify(userData);
      localStorage.setItem('user', userString);
      
      // Verify storage immediately
      const storedUser = localStorage.getItem('user');
      if (!storedUser || storedUser !== userString) {
        throw new Error('User data storage verification failed');
      }
  
      // Store token
      localStorage.setItem('token', res.accessToken);
      
      // Show success message
      const snackBarRef = this.snackBar.open('Login successful!', 'Close', {
        duration: 100,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
  
      // Wait for snackbar and storage operations
      await Promise.all([
        snackBarRef.afterDismissed().toPromise(),
        new Promise(resolve => setTimeout(resolve, 500))
      ]);
  
      // Double check storage before navigation
      const finalCheck = localStorage.getItem('user');
      if (!finalCheck || finalCheck !== userString) {
        throw new Error('Storage verification failed before navigation');
      }
  
      // Parse and navigate
      const parsedUser = JSON.parse(finalCheck);
      if (parsedUser.role_id === 1) {
        window.location.href = '/dashboard';
      } else {
        window.location.href = '/products';
      }
  
    } catch (error) {
      console.error('Login error:', error);
      localStorage.clear();
      sessionStorage.clear();
      this.snackBar.open('Login failed. Please try again.', 'Close', {
        duration: 3000,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
    }
  }
}