import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users: any[] = [];
  expandedUser: number | null = null;
  usersWithoutOrderToday: any[] = [];
  constructor(private orderService: OrderService) { }

  ngOnInit(): void {
    this.loadUsers();
       

  }

  loadUsers(): void {
    this.orderService.getOrdersByUser().subscribe({
      next: (data) => {
        this.users = data.map((user: { orders: string | any[]; }) => ({
          ...user,
          orderCount: user.orders.length
        }));
         this.filterUsersWithoutOrdersToday();
      },
      error: (err) => console.error('Error loading users:', err)
    });
  }

  toggleUserDetails(userId: number): void {
    this.expandedUser = this.expandedUser === userId ? null : userId;
  }
    private isOrderToday(orderDateString: string): boolean {
    const orderDate = new Date(orderDateString);
    const today = new Date();
    const start = new Date();
    start.setDate(start.getDate() - 1);
    start.setHours(15, 0, 0, 0); // 3:00 PM yesterday

    const end = new Date();
    end.setHours(12, 30, 0, 0); // 12:30 PM today

    return orderDate >= start && orderDate <= end;
  }

  filterUsersWithoutOrdersToday(): void {
    this.usersWithoutOrderToday = this.users.filter(user => {
      // If user has no orders, include them
      if (!user.orders || user.orderCount === 0) {
        return true;
      }
      // Otherwise, check if none of the orders were placed today
      return !user.orders.some((order: { createdAt: string; }) => this.isOrderToday(order.createdAt));
    });
  }
} 