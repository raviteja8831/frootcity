import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { Product } from '../../models/product.model';
import { ProductService } from 'src/app/services/product.service';
import { AuthService } from 'src/app/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css'],
})
export class ProductsListComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  selectedProducts: Product[] = [];
  searchTerm: string = '';
  displayedColumns: string[] = ['select', 'title', 'description','category', 'quantity'];
  pageSize: number = 5; // Number of items per page
  pageIndex = 0; 
  supplyDate: Date | null = null; // Store as a Date object
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private productservice: ProductService,
    private authService: AuthService,
    private snackBar: MatSnackBar,
    private userService: UserService, // Assuming you have a UserService for supply date
  ) {}

  ngOnInit(): void {
    this.retrieveProducts();
    this.loadSupplyDate();

  }
   onPageChange(event: PageEvent): void {
    // If the page size changed, reset to the first page.
    if (event.pageSize !== this.pageSize) {
      this.pageIndex = 0;
    } else {
      this.pageIndex = event.pageIndex;
    }
    this.pageSize = event.pageSize;
    
    // Optionally update your data source here if needed.
    // For example:
    // this.updateDataSource(this.pageIndex, this.pageSize);
  }

  onQuantityChange(product: any): void {
  if (product.quantity === 0) {
    product.quantity = undefined; // Reset to null or empty if quantity is 0
  }
}
  loadSupplyDate(): void {
    this.userService.getSupplyDate().subscribe(
      (data) => {
        console.log('Supply date loaded:', data);

        // Parse the date in dd-MM-yyyy format
        const [day, month, year] = data[0].supplydate.split('-').map(Number);
        this.supplyDate = new Date(year, month - 1, day); // Month is 0-based in JavaScript
        console.log('Parsed supply date:', this.supplyDate);
      },
      (error) => {
        console.error('Error loading supply date:', error);
      }
    );
  }
  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  retrieveProducts(): void {
    this.productservice.getAll().subscribe({
      next: (data: Product[]) => {
        this.products = data.map((product) => ({
          ...product,
          selected: false,
          quantity: undefined, // Default quantity set to undefined
        }));
        this.filteredProducts = [...this.products];
        this.dataSource.data = this.filteredProducts;
      },
      error: (e) => console.error(e),
    });
  }

  filterProducts(): void {
    this.filteredProducts = this.products.filter((product) =>
      product.title.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  updateSelectedProducts(product: Product): void {
    console.log(this.selectedProducts );
    if (product.selected) {
      this.selectedProducts.push(product);
    } else {
      this.selectedProducts = this.selectedProducts.filter(
        (item) => item.id !== product.id
      );
    }
  }
  isOrderValid(): boolean {
    // Check if all selected products have a valid quantity (greater than or equal to 1)
    return this.selectedProducts.every((product) => product.quantity && product.quantity > 0);
  }
  generateOrder(): void {
    if (this.selectedProducts.length > 0) {
      const order = this.selectedProducts
        .filter(item => item.quantity && item.quantity > 0)
        .map(item => ({
          productId: item.id,
          quantity: item.quantity??0
        }));

      const userId = this.authService.getUserId();
      const orderWithUser = {
        userId: userId,
        products: order,
      };

      this.productservice.createOrder(orderWithUser).subscribe({
        next: (response) => {
          this.snackBar.open('Order successfully created!', 'Close', {
            duration: 3000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
          // Reset selections after successful order
          this.resetSelections();
        },
        error: (e) => {
          console.error('Error creating order:', e);
          this.snackBar.open(e.error.message, 'Close', {
            duration: 3000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
        },
      });
    }
  }

  private resetSelections(): void {
    this.selectedProducts = [];
    this.products.forEach(product => {
      product.selected = false;
      product.quantity = undefined;
    });
    this.dataSource.data = [...this.products];
  }
}

// Removed the incorrect custom ViewChild function implementation
