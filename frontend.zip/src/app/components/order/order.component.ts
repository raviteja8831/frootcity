import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar } from '@angular/material/snack-bar';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { OrderService } from '../../services/order.service';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { ProductService } from 'src/app/services/product.service';
import { Product } from 'src/app/models/product.model';

interface OrderProduct {
  id: number;
  product_id: number;
  quantity: number;
  recieved_quantity: number;
  returned_quantity: number;
  product: {
    title: string;
    description: string;
    category:string
  };
}

interface Order {
  id: number;
  user_id: number;
  status: string;
  createdAt: string;
  updatedAt: string;
  products: OrderProduct[];
  totalQuantity?: number;
  received?: number;
  returned?: number;
  isEditing?: boolean;
  user?: {
    username: string;
  };
  newProduct?: any;
  showNewProductForm?: boolean;
}

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class OrderComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  products: any[] = [];
  filteredProducts: any[] = [];

  dataSource: MatTableDataSource<Order> = new MatTableDataSource<Order>();
  displayedColumns: string[] = [
    'id',
    'status',
    'user_id',
    'products',
    'totalQuantity',
    'received',
    'returned',
    'createdAt',
    'updatedAt',
    'actions'
  ];
  expandedElement: Order | null = null;

  constructor(
    private orderService: OrderService,
    private snackBar: MatSnackBar,
    private productservice: ProductService
  ) {}

  ngOnInit(): void {
    this.fetchOrdersByRole();
    this.retrieveProducts();
    this.dataSource.filterPredicate = (data: Order, filter: string) => {
  const filterValue = filter.trim().toLowerCase();
  // Include username in the search
  const username = data.user?.username ? data.user.username.toLowerCase() : '';
  const dataStr = Object.keys(data)
    .reduce((currentTerm: string, key: string) => {
      return currentTerm + (data as { [key: string]: any })[key];
    }, '')
    .toLowerCase();
  return dataStr.indexOf(filterValue) !== -1 || username.indexOf(filterValue) !== -1;
};
  }

  fetchOrdersByRole(): void {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    if (this.isAdminUser()) {
      this.fetchAllOrders();
    } else {
      this.fetchUserOrders(user.id);
    }
  }

  private fetchAllOrders(): void {
    this.orderService.getAllOrders().subscribe({
      next: (data) => this.processOrdersData(data),
      error: (error) => {
        console.error('Error fetching orders:', error);
        this.showErrorMessage('Failed to load orders');
      }
    });
  }

  private fetchUserOrders(userId: number): void {
    this.orderService.getOrdersByUserId(userId).subscribe({
      next: (data) => this.processOrdersData(data),
      error: (error) => {
        console.error('Error fetching user orders:', error);
        this.showErrorMessage('Failed to load your orders');
      }
    });
  }


  private processOrdersData(data: Order[]): void {
    data.forEach((order: Order) => {
      order.totalQuantity = this.calculateTotalQuantity(order.products);
      order.returned = this.calculateReturnedlQuantity(order.products);
      order.received = this.calculateRecievedQuantity(order.products);
      order.isEditing = false;
    });
    
    data.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    
    this.dataSource.data = data;
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  calculateTotalQuantity(products: OrderProduct[]): number {
    return products.reduce((total, product) => total + product.quantity, 0);
  }

  calculateReturnedlQuantity(products: OrderProduct[]): number {
    return products.reduce((total, product) => total + (product.returned_quantity || 0), 0);
  }

  calculateRecievedQuantity(products: OrderProduct[]): number {
    return products.reduce((total, product) => total + (product.recieved_quantity || 0), 0);
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  toggleEditMode(order: Order): void {
    this.expandedElement = this.expandedElement === order ? null : order;
    order.isEditing = !order.isEditing;
   
    // if (!order.isEditing) {
    //   this.fetchOrdersByRole();
    // }
  }

  isExpanded = (row: Order): boolean => row === this.expandedElement;

  isAdminUser(): boolean {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user?.role_id === 1;
  }

  updateOrder(order: Order): void {
    this.addNewProducts(order);
    this.orderService.updateOrder(order.id, order).subscribe({
      next: () => {
        this.fetchOrdersByRole();
        this.showSuccessMessage('Order updated successfully');
      },
      error: (error) => {
        console.error('Error updating order:', error);
        this.showErrorMessage('Failed to update order');
      }
    });
  }

  downloadOrdersAsExcel(order: Order): void {
    const worksheetData = this.prepareExcelData(order);
    const worksheet: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook: XLSX.WorkBook = {
      Sheets: { [`Order_${order.id}`]: worksheet },
      SheetNames: [`Order_${order.id}`],
    };

    const excelBuffer: any = XLSX.write(workbook, {
      bookType: 'xlsx',
      type: 'array',
    });
    
    const data: Blob = new Blob([excelBuffer], { type: 'application/octet-stream' });
    saveAs(data, `Order_${order.id}.xlsx`);
  }

  private prepareExcelData(order: Order): any[][] {
    return [
      [
      `Order ID: ${order.id}`,
      `Status: ${order.status}`,
      `User Name: ${order.user?.username}`,
      `Created Date: ${order.createdAt}`],
      [],
      ['Product Details'],
      ['Product ID', 'Title', 'Description', 'Category', 'Quantity', 'Received', 'Returned'],
      ...order.products
      .sort((a, b) => a.product.category.localeCompare(b.product.category))
      .map(product => [
        product.product_id,
        product.product.title,
        product.product.description,
        product.product.category,
        product.quantity,
        product.recieved_quantity || 0,
        product.returned_quantity || 0,
      ]),
    ];
  }

  getProductsTooltip(order: Order): string {
    return order.products?.length 
      ? order.products.map(product => 
          `${product.product.description} (${product.quantity})`
        ).join('\n')
      : 'No products';
  }

  private showSuccessMessage(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      verticalPosition: 'top',
      horizontalPosition: 'center'
    });
  }

  private showErrorMessage(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      verticalPosition: 'top',
      horizontalPosition: 'center'
    });
  }
  retrieveProducts(): void {
  this.productservice.getAll().subscribe({
    next: (data: Product[]) => {
      this.products = data;
     
    },
    error: (e) => console.error(e),
  });
}
 addDynamicProduct(order: any): void {
    if (!order.newProducts) {
      order.newProducts = [];
    }
    // Push a new blank product entry
    order.newProducts.push({ product_id: null, quantity: null });
  }

  // Remove a product entry at the given index
  removeNewProduct(order: any, index: number): void {
    if (order.newProducts && order.newProducts.length > index) {
      order.newProducts.splice(index, 1);
    }
  }

  // Optionally update your addNewProduct function to handle newProducts array,
  // e.g. merging order.newProducts with order.products, and then calling your update API.
  addNewProducts(order: any): void {
    if (order.newProducts && order.newProducts.length) {
      // Process each new product and append it to the order.products array.
      order.newProducts.forEach((newProd: { product_id: any; quantity: any; }) => {
        // Create a new product object; you may adjust details as needed.
        const productToAdd = {
          product_id: newProd.product_id,
          product: this.products.find(p => p.id === newProd.product_id),  // for display purposes
          quantity: newProd.quantity,
          recieved_quantity: 0,
          returned_quantity: 0
        };
        order.products.push(productToAdd);
      });
      // Optionally clear the newProducts array after processing
      order.newProducts = [];
      // Trigger update order API call if needed.
    
    } 
  }
  toggleNewProductForm(order: Order): void {
  order.showNewProductForm = !order.showNewProductForm;
}
}