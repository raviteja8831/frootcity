import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ProductService } from 'src/app/services/product.service';

interface Product {
  id: number;
  title: string;
  description: string;
  status: number; // 1 for Available, 0 for Unavailable
}

@Component({
  selector: 'app-product-status',
  templateUrl: './product-status.component.html',
  styleUrls: ['./product-status.component.css']
})
export class ProductStatusComponent implements OnInit {
  displayedColumns: string[] = ['id', 'title', 'description','category', 'status'];  dataSource: MatTableDataSource<Product> = new MatTableDataSource<Product>();

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private productService: ProductService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.retrieveProducts();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  retrieveProducts(): void {
    this.productService.getAllProducts().subscribe({
      next: (data: Product[]) => {
        this.dataSource.data = data;
      },
      error: (e) => {
        console.error('Error fetching products:', e);
        this.snackBar.open('Failed to load products', 'Close', { duration: 3000 });
      }
    });
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  updateProductStatus(product: Product, newStatus: number): void {
    const updatedProduct = { ...product, status: newStatus };
    this.productService.updateProductStatus(product.id, updatedProduct).subscribe({
      next: () => {
        product.status = newStatus; // Update the status in the UI
        this.snackBar.open(
          `Product status updated to ${newStatus === 1 ? 'Available' : 'Unavailable'}`,
          'Close',
          { duration: 3000 }
        );
      },
      error: (e) => {
        console.error('Error updating product status:', e);
        this.snackBar.open('Failed to update product status', 'Close', { duration: 3000 });
      }
    });
  }
}