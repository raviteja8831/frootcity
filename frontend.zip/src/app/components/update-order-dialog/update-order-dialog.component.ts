import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-update-order-dialog',
  templateUrl: './update-order-dialog.component.html',
  styleUrls: ['./update-order-dialog.component.css']
})
export class UpdateOrderDialogComponent {
  updatedStatus: string = 'sent';
  isAdmin: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<UpdateOrderDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.isAdmin = data.isAdmin; // Determine if the user is an admin
    this.updatedStatus = data.order.status; // Set the initial status to the current order status
  }

  onSave(): void {
    const updatedOrder = {
      ...this.data.order,
      status: this.updatedStatus,
      products: this.data.order.products
    };
    this.dialogRef.close(updatedOrder);
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}