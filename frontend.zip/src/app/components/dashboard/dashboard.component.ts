import { Component, OnInit, ViewChild } from '@angular/core';
import * as XLSX from 'xlsx';
import { OrderService } from '../../services/order.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup } from '@angular/forms';
interface ProductSummary {
  productName: string;
  description:string;
  totalQuantity: number;
  receivedQuantity: number;
  returnedQuantity: number;
}
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  orders: any[] = []; // Store all orders for dynamic updates
  userQuantities: any[] = []; // Data for user-wise quantities chart
  productQuantities: any[] = []; // Data for product-wise quantities chart
  overallQuantities: any[] = []; // Data for overall quantities chart
  dateRange = new FormGroup({
    start: new FormControl(),
    end: new FormControl()
  });

  // Chart options
  view: [number, number] = [700, 400]; // Chart dimensions
  showLegend = true;
  showLabels = true;
  isDoughnut = false;
  userOrderCounts: any[] = []; // Data for user-wise orders count chart
  displayedColumns: string[] = ['productName', 'description',  'totalQuantity', 'receivedQuantity', 'returnedQuantity'];
  dataSource!: MatTableDataSource<ProductSummary>;
  usersWithoutOrder: any[] = [];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private orderService: OrderService) {
    this.dateRange.valueChanges.subscribe(() => {
      this.applyDateFilter();
    });
  }
  applyDateFilter() {
    // Filter orders by date range first
    let filteredOrders = this.orders;
    if (this.dateRange.value.start && this.dateRange.value.end) {
      const startDate = new Date(this.dateRange.value.start);
      const endDate = new Date(this.dateRange.value.end);
     const startDateOnly = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
      const endDateOnly = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());
      filteredOrders = this.orders.filter(order => {
      const orderDate = new Date(order.createdAt);
      // Compare only the date part (ignore time)
      const orderDateOnly = new Date(orderDate.getFullYear(), orderDate.getMonth(), orderDate.getDate());
     
      return orderDateOnly >= startDateOnly && orderDateOnly <= endDateOnly;
      });
    }

    // Prepare table data from filtered orders
    const productMap = new Map<string, ProductSummary>();
    filteredOrders.forEach(order => {
      order.products.forEach((product: any) => {
      const productName = product.product.title;
      const description = product.product.description;

      const existing = productMap.get(productName) || {
        productName,
        description,
        totalQuantity: 0,
        receivedQuantity: 0,
        returnedQuantity: 0
      };

      existing.totalQuantity += Number(product.quantity) || 0;
      existing.receivedQuantity += Number(product.received_quantity) || 0;
      existing.returnedQuantity += Number(product.returned_quantity) || 0;

      productMap.set(productName, existing);
      });
    });

    const tableData = Array.from(productMap.values());
    this.dataSource = new MatTableDataSource(tableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  ngOnInit(): void {
    this.fetchOrders();
  }


  exportToExcel(): void {
    const filteredData = this.dataSource.filteredData;
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    
    // Generate Excel file
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const startDate = this.dateRange.value.start ? new Date(this.dateRange.value.start).toISOString().split('T')[0] : '';
    const endDate = this.dateRange.value.end ? new Date(this.dateRange.value.end).toISOString().split('T')[0] : ' ';
    // Format dates to dd-mm-yyyy
  
    const formattedStartDate = this.formatDate(this.dateRange.value.start);
    const formattedEndDate = this.formatDate(this.dateRange.value.end);
    const filename = `products_report_${formattedStartDate}_to_${formattedEndDate}.xlsx`;

    this.saveExcelFile(excelBuffer, filename);
  }
  applyDateRangeFilter(): void {
    if (!this.dateRange.value.start || !this.dateRange.value.end) {
      return; // If no date range is selected, do nothing
    }
  
    const startDate = new Date(this.dateRange.value.start);
    const endDate = new Date(this.dateRange.value.end);
      const startDateOnly = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
      const endDateOnly = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());
    this.orders = this.orders.filter(order => {
      const orderDate = new Date(order.createdAt); // Assuming `createdAt` is the order date field
      // Compare only the date part (ignore time)
      const orderDateOnly = new Date(orderDate.getFullYear(), orderDate.getMonth(), orderDate.getDate());

      return orderDateOnly >= startDateOnly && orderDateOnly <= endDateOnly;
    });
  }
 formatDate (dateStr: string): string {
      if (!dateStr) return '';
      const date = new Date(dateStr);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      return `${day}-${month}-${year}`;
    };
  exportOrdersData() {
    // Initialize data for the worksheet
    const worksheetData = [];
  this.applyDateRangeFilter();
    // Get unique usernames
    const uniqueUsernames = Array.from(new Set(this.orders.map(order => order.user?.username)));
  
    // Add headers (users in columns + Total Quantity)
    const headers = [
      "Product Title",
      "Product Description",
      "Category",
      ...uniqueUsernames.map(username => `(${username})`),
      "Total Quantity"
    ];
    worksheetData.push(headers);
  
    // Process each product and aggregate quantities
    const productMap = new Map<string, any>();
  
    this.orders.forEach(order => {
      order.products.forEach((product: any) => {
        const productKey = `${product.product.title}`;
  
        // If the product doesn't exist in the map, create a new row
        if (!productMap.has(productKey)) {
          productMap.set(productKey, {
            title: product.product.title,
            description: product.product.description,
            category: product.product.category,

            userQuantities: new Map(uniqueUsernames.map(username => [username, 0])),
            totalQuantity: 0
          });
        }
  
        // Update the product data
        const productData = productMap.get(productKey);
        const username = order.user?.username;
        if (username) {
          productData.userQuantities.set(username, productData.userQuantities.get(username) + product.quantity);
        }
        productData.totalQuantity += product.quantity;
      });
    });
  
    // Add rows for each product
    productMap.forEach(productData => {
      const row = [
        productData.title,
        productData.description,
        productData.category,
        ...uniqueUsernames.map(username => productData.userQuantities.get(username) || 0),
        productData.totalQuantity
      ];
      worksheetData.push(row);
    });
  // Sort worksheetData rows (excluding header) by the "Category" column (index 2)
  worksheetData.splice(1, worksheetData.length - 1, 
    ...worksheetData.slice(1).sort((a, b) => {
    const catA = (a[2] || '').toString().toLowerCase();
    const catB = (b[2] || '').toString().toLowerCase();
    return catA.localeCompare(catB);
    })
  );
    // Create a worksheet
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
  
    // Create a workbook
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Products Data");
  
    // Write to an Excel file
    const startDate = this.dateRange.value.start ? new Date(this.dateRange.value.start).toISOString().split('T')[0] : '';
    const endDate = this.dateRange.value.end ? new Date(this.dateRange.value.end).toISOString().split('T')[0] : ' ';
    // Format dates to dd-mm-yyyy
  
    const formattedStartDate = this.formatDate(this.dateRange.value.start);
    const formattedEndDate = this.formatDate(this.dateRange.value.end);
    const filename = `products_report_${formattedStartDate}_to_${formattedEndDate}.xlsx`;
    XLSX.writeFile(workbook, filename);
  }
  private saveExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });
    const downloadLink = document.createElement('a');
    downloadLink.href = window.URL.createObjectURL(data);
    downloadLink.download = `${fileName}`;
    downloadLink.click();
  }

  exportTotalReceivedData(): void {
    // Filter orders by date range
    const filteredOrders = this.filterOrdersByDate();

    // Calculate total received quantity for each user
    const totalReceivedData = filteredOrders.reduce((acc, order) => {
      const username = order.user?.username || 'Unknown';
      const totalReceived = order.products.reduce((sum: number, product: any) => sum + (product.received_quantity || 0), 0);

      const existingUser = acc.find((item: any) => item.Username === username);
      if (existingUser) {
        existingUser.TotalReceived += totalReceived;
      } else {
        acc.push({ Username: username, TotalReceived: totalReceived });
      }
      return acc;
    }, []);

    // Convert to Excel
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(totalReceivedData);
    const workbook: XLSX.WorkBook = { Sheets: { 'Total Received': worksheet }, SheetNames: ['Total Received'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const startDate = this.dateRange.value.start ? new Date(this.dateRange.value.start).toISOString().split('T')[0] : '';
    const endDate = this.dateRange.value.end ? new Date(this.dateRange.value.end).toISOString().split('T')[0] : ' ';
    // Format dates to dd-mm-yyyy
  
    const formattedStartDate = this.formatDate(this.dateRange.value.start);
    const formattedEndDate = this.formatDate(this.dateRange.value.end);
    const filename = `Total_Received_Data_${formattedStartDate}_to_${formattedEndDate}.xlsx`;
    this.saveExcelFile(excelBuffer, filename);
  }

  exportTotalReturnedData(): void {
    // Filter orders by date range
    const filteredOrders = this.filterOrdersByDate();

    // Calculate total returned quantity for each user
    const totalReturnedData = filteredOrders.reduce((acc, order) => {
      const username = order.user?.username || 'Unknown';
      const totalReturned = order.products.reduce((sum: number, product: any) => sum + (product.returned_quantity || 0), 0);

      const existingUser = acc.find((item: any) => item.Username === username);
      if (existingUser) {
        existingUser.TotalReturned += totalReturned;
      } else {
        acc.push({ Username: username, TotalReturned: totalReturned });
      }
      return acc;
    }, []);

    // Convert to Excel
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(totalReturnedData);
    const workbook: XLSX.WorkBook = { Sheets: { 'Total Returned': worksheet }, SheetNames: ['Total Returned'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const startDate = this.dateRange.value.start ? new Date(this.dateRange.value.start).toISOString().split('T')[0] : '';
    const endDate = this.dateRange.value.end ? new Date(this.dateRange.value.end).toISOString().split('T')[0] : ' ';
    // Format dates to dd-mm-yyyy
  
    const formattedStartDate = this.formatDate(this.dateRange.value.start);
    const formattedEndDate = this.formatDate(this.dateRange.value.end);
    const filename = `Total_Returned_Data_${formattedStartDate}_to_${formattedEndDate}.xlsx`;

    this.saveExcelFile(excelBuffer, filename);
  }

  private filterOrdersByDate(): any[] {
    if (!this.dateRange.value.start || !this.dateRange.value.end) {
      return this.orders; // Return all orders if no date range is selected
    }

    const startDate = new Date(this.dateRange.value.start);
    const endDate = new Date(this.dateRange.value.end);

    return this.orders.filter(order => {
      const orderDate = new Date(order.createdAt); // Assuming `createdAt` is the order date field
      return orderDate >= startDate && orderDate <= endDate;
    });
  }
  fetchOrders(): void {
    this.orderService.getAllOrders().subscribe((orders: any[]) => {
      this.orders = orders;
      this.createCharts();
      this.createUserOrderCountChart();
      this.prepareTableData();

    });
  }
  prepareTableData(): void {
    const productMap = new Map<string, ProductSummary>();

    this.orders.forEach(order => {
      order.products.forEach((product: any) => {
        const productName = product.product.title;
        const description = product.product.description;

        const existing = productMap.get(productName) || {
          productName,
          description,
          totalQuantity: 0,
          receivedQuantity: 0,
          returnedQuantity: 0
        };

        existing.totalQuantity += Number(product.quantity) || 0;
        existing.receivedQuantity += Number(product.received_quantity) || 0;
        existing.returnedQuantity += Number(product.returned_quantity) || 0;

        productMap.set(productName, existing);
      });
    });

    const tableData = Array.from(productMap.values());
    this.dataSource = new MatTableDataSource(tableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  createCharts(): void {
    this.userQuantities = this.aggregateData(this.orders, 'user.username');
    this.productQuantities = this.aggregateData(this.orders, 'product.description');
    this.overallQuantities = this.calculateOverallQuantities();
  }

  private aggregateData(orders: any[], keyPath: string): any[] {
    const dataMap: { [key: string]: number } = {};

    orders.forEach(order => {
      order.products.forEach((product: any) => {
        const key = this.getNestedValue(order, keyPath) || this.getNestedValue(product, keyPath);
        if (!dataMap[key]) {
          dataMap[key] = 0;
        }
        dataMap[key] += Number(product.quantity) || 0;
      });
    });

    return Object.entries(dataMap).map(([key, value]) => ({
      name: key,
      value
    }));
  }

  private calculateOverallQuantities(): any[] {
    const quantities = { Total: 0, Received: 0, Returned: 0 };

    this.orders.forEach(order => {
      order.products.forEach((product: any) => {
        quantities.Total += Number(product.quantity) || 0;
        quantities.Received += Number(product.received_quantity) || 0;
        quantities.Returned += Number(product.returned_quantity) || 0;
      });
    });

    return [
      { name: 'Total', value: quantities.Total },
      { name: 'Received', value: quantities.Received },
      { name: 'Returned', value: quantities.Returned }
    ];
  }

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((acc, part) => acc && acc[part], obj);
  }
  createUserOrderCountChart(): void {
    const userOrderMap: { [key: string]: number } = {};

    this.orders.forEach(order => {
      const username = order.user?.username || 'Unknown';
      if (!userOrderMap[username]) {
        userOrderMap[username] = 0;
      }
      userOrderMap[username]++;
    });

    this.userOrderCounts = Object.entries(userOrderMap).map(([name, value]) => ({
      name,
      value
    }));
  }
}
