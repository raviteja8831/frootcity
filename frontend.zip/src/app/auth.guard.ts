import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const user = localStorage.getItem('user');
    const userObj = user ? JSON.parse(user) : null;
    const roleId = userObj?.role_id;

    // Handle base URL
    if (state.url === '/') {
      if (user) {
        if (roleId === 1) {
          this.router.navigate(['/dashboard']);
        } else {
          this.router.navigate(['/products']);
        }
      } else {
        this.router.navigate(['/login']);
      }
      return false;
    }

    // Check if trying to access login page while already logged in
    if (state.url.includes('login') && user) {
      if (roleId === 1) {
        this.router.navigate(['/dashboard']);
      } else {
        this.router.navigate(['/products']);
      }
      return false;
    }

    // If not logged in and trying to access protected routes, redirect to login
    if (!user && !state.url.includes('login')) {
      localStorage.clear();
      this.router.navigate(['/login']);
      return false;
    }

    return true;
  }
}