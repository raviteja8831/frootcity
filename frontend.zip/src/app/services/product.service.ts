import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../models/product.model';

const baseUrl = 'http://www.frootcity.com/api/products';
const ordersUrl = 'http://www.frootcity.com/api/orders/create'; // Add orders endpoint


@Injectable({
  providedIn: 'root',
})
export class ProductService {
  constructor(private http: HttpClient) {}

  getAll(): Observable<Product[]> {
    return this.http.get<Product[]>(baseUrl);
  }
  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(baseUrl+"/all");
  }
  createOrder(order: { userId: number; products: { productId: number; quantity: number }[] }): Observable<any> {
    return this.http.post<any>(`${ordersUrl}`, order); // Add createOrder method
  }
  updateProductStatus(productId: number, updatedProduct: any): Observable<any> {
    return this.http.put<any>(`${baseUrl}/${productId}/status`, { status: updatedProduct.status });
  }
}
