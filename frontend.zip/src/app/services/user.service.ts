import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const baseUrl = 'http://www.frootcity.com/api/users';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient) {}
  private apiEndpoint =  baseUrl + '/supplydate'; // Backend API endpoint

  register(data: any): Observable<any> {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    if (user && user.role_id === 1) {
      return this.http.post(`${baseUrl}/register`, data);
    } else {
      throw new Error('Unauthorized: Only logged-in users ');
    }
  }

  login(data: any): Observable<any> {
    return this.http.post(`${baseUrl}/login`, data);
  }
   // Method to get the current supply date
   getSupplyDate(): Observable<any> {
    return this.http.get(this.apiEndpoint);
  }

  // Method to update the supply date
  updateSupplyDate(supplyDate: { date: string, id:number}): Observable<any> {
    return this.http.put(this.apiEndpoint, supplyDate);
  }
}