import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const baseUrl = 'http://www.frootcity.com/api/orders';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  constructor(private http: HttpClient) {}

  getAllOrders(): Observable<any> {
    return this.http.get(`${baseUrl}`);
  }

  getOrdersByUserId(userId: number): Observable<any> {
    return this.http.get(`${baseUrl}/user/${userId}`);
  }
  updateOrder(orderId: number, orderData: any): Observable<any> {
    return this.http.put<any>(`${baseUrl}/${orderId}`, orderData);
  }
  getOrdersByUser(): Observable<any> {
    return this.http.get(`${baseUrl}/by-user`);
  }
}